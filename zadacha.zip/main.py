from flask import Flask, url_for, render_template, redirect
from flask_wtf import FlaskForm
from data import db_session
from data.users import User
from data.works import Work
from forms.user import RegisterForm
from requests import request


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/users.db")
    app.run()


@app.route("/success")
def index():
    return render_template('success.html')


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    print(form.errors)
    db_sess = db_session.create_session()
    if form.validate_on_submit():
        print(1)
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data,
            surname=form.surname.data,
            age=form.age.data,
            address=form.address.data,
            position=form.position.data,
            speciality=form.speciality.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/success')
    return render_template('register.html', title='Регистрация', form=form)


if __name__ == '__main__':
    main()
